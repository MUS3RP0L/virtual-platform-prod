CREATE FUNCTION sum_contributionsc (month1 integer, year1 integer, OUT count_id bigint, OUT salary numeric, OUT seniority_bonus numeric, OUT study_bonus numeric, OUT position_bonus numeric, OUT border_bonus numeric, OUT east_bonus numeric, OUT public_security_bonus numeric, OUT gain numeric, OUT quotable numeric, OUT total numeric, OUT retirement_fund numeric, OUT mortuary_quota numeric) RETURNS SETOF record
	LANGUAGE plpgsql
AS $$
            BEGIN
            RETURN QUERY SELECT COUNT(DISTINCT(contributions.id)) count_id, SUM(contributions.base_wage) salary, SUM(contributions.seniority_bonus) seniority_bonus,SUM(contributions.study_bonus) study_bonus, SUM(contributions.position_bonus) position_bonus, SUM(contributions.border_bonus) border_bonus, SUM(contributions.east_bonus) east_bonus,SUM(contributions.public_security_bonus) public_security_bonus, SUM(contributions.gain) gain, SUM(contributions.quotable) quotable, SUM(contributions.total) total,SUM(contributions.retirement_fund) retirement_fund, SUM(contributions.mortuary_quota) mortuary_quota
            FROM contributions WHERE extract(month from contributions.month_year) = month1 and extract(year from contributions.month_year) = year1 and contributions.breakdown_id <> 5;
            END; 
$$
